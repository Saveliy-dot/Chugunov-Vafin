﻿using MySql.Data.MySqlClient;

namespace databases;

public record Author(
    string FirstName, 
    string LastName,
    int Id = 0
) {
    public string FullName => $"{FirstName} {LastName}";
};
public record Book(
    string Title, 
    int AuthorId,
    int PublicationYear,
    string Genre,
    int Id = 0
);
public record Borrowing(
    int ReaderId,
    int BookId,
    DateTime BorrowDate,
    DateTime? ReturnDate,
    int Id = 0
) {
    public string BorrowDateString => BorrowDate.ToString("yyyy-MM-dd");
    public string ReturnDateString => ReturnDate?.ToString("yyyy-MM-dd") ?? "not set";
};
public record Reader(
    string FirstName, 
    string LastName,
    string Phone,
    int Id = 0
) {
    public string FullName => $"{FirstName} {LastName}";
};

public class Database
{
    private readonly MySqlConnection _connection = new(
        "server=localhost; user=root; database=library; port=3306; password=database"
        );
    
    public List<Author> GetAuthors() 
    {
        List<Author> authors = new();
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand("SELECT * FROM authors", _connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Author author = new(
                    reader["firstname"].ToString()!,
                    reader["lastname"].ToString()!,
                    Convert.ToInt32(reader["id_author"])
                );
                authors.Add(author);
            }
            reader.Close();
        }
        catch (Exception ex) {
            Console.WriteLine(ex);
        }
        finally {
            _connection.Close();
        }
        return authors;
    }
    public void InsertAuthor(Author author)
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "INSERT INTO authors (firstname, lastname) VALUES ( @firstname, @lastname )", 
                _connection
                );
            command.Parameters.AddWithValue("@firstname", author.FirstName);
            command.Parameters.AddWithValue("@lastname", author.LastName);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
    public void DeleteAuthor(int authorId) 
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "DELETE FROM authors WHERE id_author = @author_id", 
                _connection
            );
            command.Parameters.AddWithValue("@author_id", authorId);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
    
    public List<Book> GetBooks() 
    {
        List<Book> books = new();
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand("SELECT * FROM books", _connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Book book = new(
                    reader["title"].ToString()!,
                    Convert.ToInt32(reader["author_id"]),
                    Convert.ToInt32(reader["publication_year"]),
                    reader["genre"].ToString()!,
                    Convert.ToInt32(reader["id_book"])
                );
                books.Add(book);
            }
            reader.Close();
        }
        catch (Exception ex) {
            Console.WriteLine(ex);
        }
        finally {
            _connection.Close();
        }
        return books;
    }
    public void InsertBook(Book book)
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "INSERT INTO books (title, author_id, publication_year, genre) " +
                "VALUES ( @title, @author_id, @publication_year, @genre)", 
                _connection
            );
            command.Parameters.AddWithValue("@title", book.Title);
            command.Parameters.AddWithValue("@author_id", book.AuthorId);
            command.Parameters.AddWithValue("@publication_year", book.PublicationYear);
            command.Parameters.AddWithValue("@genre", book.Genre);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
    public void DeleteBook(int bookId) 
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "DELETE FROM books WHERE id_book = @book_id", 
                _connection
            );
            command.Parameters.AddWithValue("@book_id", bookId);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
    
    public List<Reader> GetReaders() 
    {
        List<Reader> readers = new();
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand("SELECT * FROM readers", _connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Reader r = new(
                    reader["firstname"].ToString()!,
                    reader["lastname"].ToString()!,
                    reader["phone"].ToString()!,
                    Convert.ToInt32(reader["id_reader"])
                );
                readers.Add(r);
            }
            reader.Close();
        }
        catch (Exception ex) {
            Console.WriteLine(ex);
        }
        finally {
            _connection.Close();
        }
        return readers;
    }
    public void InsertReader(Reader reader)
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "INSERT INTO readers (firstname, lastname, phone) " +
                "VALUES ( @firstname, @lastname, @phone )", 
                _connection
            );
            command.Parameters.AddWithValue("@firstname", reader.FirstName);
            command.Parameters.AddWithValue("@lastname", reader.LastName);
            command.Parameters.AddWithValue("@phone", reader.Phone);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
    public void DeleteReader(int readerId) 
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "DELETE FROM readers WHERE id_reader = @reader_id", 
                _connection
            );
            command.Parameters.AddWithValue("@reader_id", readerId);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
    
    public List<Borrowing> GetBorrowings() 
    {
        List<Borrowing> borrowings = new();
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand("SELECT * FROM borrowings", _connection);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                DateTime? returnDate = reader["return_date"] is DBNull ? null : DateTime.ParseExact(reader["return_date"].ToString()!, "dd.MM.yyyy H:mm:ss", null);
                Borrowing borrowing = new(
                    Convert.ToInt32(reader["reader_id"]),
                    Convert.ToInt32(reader["book_id"]),
                    DateTime.ParseExact(reader["borrow_date"].ToString()!, "dd.MM.yyyy H:mm:ss", null),
                    returnDate,
                    Convert.ToInt32(reader["id_borrowing"])
                );
                borrowings.Add(borrowing);
            }
            reader.Close();
        }
        catch (Exception ex) {
            Console.WriteLine(ex);
        }
        finally {
            _connection.Close();
        }
        return borrowings;
    }
    public void InsertBorrowing(Borrowing borrowing) 
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "INSERT INTO borrowings (reader_id, book_id, borrow_date) " +
                "VALUES ( @reader_id, @book_id, @borrow_date )", 
                _connection
            );
            command.Parameters.AddWithValue("@reader_id", borrowing.ReaderId);
            command.Parameters.AddWithValue("@book_id", borrowing.BookId);
            command.Parameters.AddWithValue("@borrow_date", borrowing.BorrowDate);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
    public void SetBorrowingReturnDate(int borrowingId, DateTime returnDate) 
    {
        try
        {
            _connection.Open();
            MySqlCommand command = new MySqlCommand(
                "UPDATE borrowings SET return_date = @return_date WHERE id_borrowing = @borrowing_id", 
                _connection
            );
            command.Parameters.AddWithValue("@return_date", returnDate);
            command.Parameters.AddWithValue("@borrowing_id", borrowingId);
            command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
        finally
        {
            _connection.Close();
        }
    }
}