﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using databases.pages;
using databases.pages.AuthorsPage;
using databases.pages.BooksPage;
using databases.pages.BorrowingsPage;
using databases.pages.ReadersPage;

namespace databases;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Frame.Navigate(new ReadersPage());
    }

    private void NavigateToAuthors(object sender, RoutedEventArgs e)
    {
        Frame.Navigate(new AuthorsPage());
    }

    private void NavigateToBooks(object sender, RoutedEventArgs e)
    {
        Frame.Navigate(new BooksPage());
    }

    private void NavigateToReaders(object sender, RoutedEventArgs e)
    {
        Frame.Navigate(new ReadersPage());
    }

    private void NavigateToBorrowings(object sender, RoutedEventArgs e)
    {
        Frame.Navigate(new BorrowingsPage());
    }
}