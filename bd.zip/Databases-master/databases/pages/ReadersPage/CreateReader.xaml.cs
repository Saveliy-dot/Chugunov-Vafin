﻿using System.Windows;

namespace databases.pages.ReadersPage;

public partial class CreateReader : Window
{
    public Reader? NewReader { get; private set; }
    public CreateReader()
    {
        InitializeComponent();
    }

    private void OnAddButtonClick(object sender, RoutedEventArgs e)
    {
        var firstName = FirstnameTb.Text;
        var lastName = LastnameTb.Text;
        var phone = PhoneTb.Text;

        if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName) || string.IsNullOrWhiteSpace(phone))
        {
            MessageBox.Show("Please fill all fields", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        NewReader = new Reader(firstName, lastName, phone);
        Close();
    }
}