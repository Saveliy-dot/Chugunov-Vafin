﻿using System.Windows;
using System.Windows.Controls;

namespace databases.pages.ReadersPage;

public partial class ReadersPage : Page
{
    private readonly Database _db = new();
    public ReadersPage()
    {
        InitializeComponent();
        UpdateItems();
    }

    private void UpdateItems()
    {
        ReadersLb.ItemsSource = _db.GetReaders();
    }

    private void OnDeleteReaderClick(object sender, RoutedEventArgs e)
    {
        if (ReadersLb.SelectedItem is not Reader selectedReader)
        {
            MessageBox.Show(
                "Пожалуйста, выберите читателя для удаления.",
                "Ошибка",
                MessageBoxButton.OK, 
                MessageBoxImage.Warning
            );
            return;
        }

        var show = MessageBox.Show(
            $"Вы действительно хотите удалить читателя {selectedReader.FullName} ({selectedReader.Phone})?",
            "Подтверждение удаления",
            MessageBoxButton.YesNo
        );
        if (show != MessageBoxResult.Yes) return;
        _db.DeleteReader(selectedReader.Id);
        UpdateItems();
        MessageBox.Show("Читатель успешно удален.");
    }

    private void OnAddReaderClick(object sender, RoutedEventArgs e)
    {
        CreateReader window = new();
        if (window.ShowDialog() == null || window.NewReader == null) return;
        _db.InsertReader(window.NewReader);
        UpdateItems();
    }
}