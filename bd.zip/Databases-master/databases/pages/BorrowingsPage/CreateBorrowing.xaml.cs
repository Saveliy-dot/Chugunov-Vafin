﻿using System.Windows;

namespace databases.pages.BorrowingsPage;

public partial class CreateBorrowing : Window
{
    public Borrowing? NewBorrowing { get; private set; }
    public CreateBorrowing(List<Reader> readers, List<Book> books)
    {
        InitializeComponent();
        ReaderCb.ItemsSource = readers;
        ReaderCb.SelectedIndex = 0;
        BookCb.ItemsSource = books;
        BookCb.SelectedIndex = 0;
    }

    private void OnAddButtonClick(object sender, RoutedEventArgs e)
    {
        NewBorrowing = new Borrowing(
            (ReaderCb.SelectedItem as Reader)!.Id,
            (BookCb.SelectedItem as Book)!.Id,
            DateTime.Now,
            null
        );
        Close();
    }
}