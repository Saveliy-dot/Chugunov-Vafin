﻿using System.Windows;
using System.Windows.Controls;
using databases.pages.BooksPage;

namespace databases.pages.BorrowingsPage;

public partial class BorrowingsPage : Page
{
    private readonly List<Book> _books;
    private readonly List<Reader> _readers;
    private readonly Database _db = new();
    public BorrowingsPage()
    {
        InitializeComponent();
        UpdateItems();
        
        _books = _db.GetBooks();
        _readers = _db.GetReaders();
    }

    private void UpdateItems()
    {
        BorrowingsLb.ItemsSource = _db.GetBorrowings();
    }

    private void OnAddBorrowingClick(object sender, RoutedEventArgs e)
    {
        CreateBorrowing window = new(_readers, _books);
        if (window.ShowDialog() == null || window.NewBorrowing == null) return;
        _db.InsertBorrowing(window.NewBorrowing);
        UpdateItems();
    }

    private void OnUpdateBorrowingClick(object sender, RoutedEventArgs e)
    {
        if (BorrowingsLb.SelectedItem is not Borrowing selectedBorrowing)
        {
            MessageBox.Show(
                "Пожалуйста, выберите запись для обновления.",
                "Ошибка",
                MessageBoxButton.OK, 
                MessageBoxImage.Warning
            );
            return;
        }

        var show = MessageBox.Show(
            $"Вы действительно хотите обновить запись от {selectedBorrowing.BorrowDate:yyyy-MM-dd}?",
            "Подтверждение обновления",
            MessageBoxButton.YesNo
        );
        if (show != MessageBoxResult.Yes) return;
        _db.SetBorrowingReturnDate(selectedBorrowing.Id, DateTime.Now);
        UpdateItems();
        MessageBox.Show("Запись успешно удалена.");
    }
}