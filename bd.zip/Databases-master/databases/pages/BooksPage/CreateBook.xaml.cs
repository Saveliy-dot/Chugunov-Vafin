﻿using System.Windows;
using System.Windows.Controls;

namespace databases.pages.BooksPage;

public partial class CreateBook : Window
{
    public Book? NewBook { get; private set; }
    public CreateBook(List<Author> authors)
    {
        InitializeComponent();
        AuthorCb.ItemsSource = authors;
        AuthorCb.SelectedIndex = 0;
    }

    private void OnAddButtonClick(object sender, RoutedEventArgs e)
    {
        if (
            string.IsNullOrWhiteSpace(TitleTb.Text) ||
            string.IsNullOrWhiteSpace(PublicationYearTb.Text) ||
            string.IsNullOrWhiteSpace(GenreTb.Text)
            ) {
            MessageBox.Show("Please fill all fields", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var isNumeric = int.TryParse(PublicationYearTb.Text, out var publicationYear);
        if (!isNumeric) 
        {
            MessageBox.Show("Public year must be an integer", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        NewBook = new Book(
            TitleTb.Text,
            (AuthorCb.SelectedItem as Author)!.Id,
            publicationYear,
            GenreTb.Text
        );
        Close();
    }
}