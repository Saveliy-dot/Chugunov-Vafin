﻿using System.Windows;
using System.Windows.Controls;

namespace databases.pages.BooksPage;

public partial class BooksPage : Page
{
    private readonly Database _db = new();
    
    private readonly List<Author> _authors;
    
    public BooksPage()
    {
        InitializeComponent();
        UpdateItems();
        _authors = _db.GetAuthors();
    }

    private void UpdateItems()
    {
        BooksLb.ItemsSource = _db.GetBooks();
    }

    private void OnDeleteBookClick(object sender, RoutedEventArgs e)
    {
        if (BooksLb.SelectedItem is not Book selectedBook)
        {
            MessageBox.Show(
                "Пожалуйста, выберите книгу для удаления.",
                "Ошибка",
                MessageBoxButton.OK, 
                MessageBoxImage.Warning
            );
            return;
        }

        var show = MessageBox.Show(
            $"Вы действительно хотите удалить книгу {selectedBook.Title} ({selectedBook.PublicationYear}) - {selectedBook.Genre}?",
            "Подтверждение удаления",
            MessageBoxButton.YesNo
        );
        if (show != MessageBoxResult.Yes) return;
        _db.DeleteBook(selectedBook.Id);
        UpdateItems();
        MessageBox.Show("Книга успешно удалена.");
    }

    private void OnAddBookClick(object sender, RoutedEventArgs e)
    {
        CreateBook window = new(_authors);
        if (window.ShowDialog() == null || window.NewBook == null) return;
        _db.InsertBook(window.NewBook);
        UpdateItems();
    }
}