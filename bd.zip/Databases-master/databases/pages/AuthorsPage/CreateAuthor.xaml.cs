﻿using System.Windows;

namespace databases.pages.AuthorsPage;

public partial class CreateAuthor : Window
{
    public Author? NewAuthor { get; private set; }

    public CreateAuthor()
    {
        InitializeComponent();
    }

    private void OnAddButtonClick(object sender, RoutedEventArgs e)
    {
        var firstName = FirstnameTb.Text;
        var lastName = LastnameTb.Text;

        if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
        {
            MessageBox.Show("Please fill all fields", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        NewAuthor = new Author(firstName, lastName);
        Close();
    }
}