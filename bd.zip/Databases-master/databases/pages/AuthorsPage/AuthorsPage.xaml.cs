﻿using System.Windows;
using System.Windows.Controls;

namespace databases.pages.AuthorsPage;

public partial class AuthorsPage : Page
{
    private readonly Database _db = new();

    public AuthorsPage()
    {
        InitializeComponent();
        UpdateItems();
    }

    private void UpdateItems()
    {
        AuthorsLb.ItemsSource = _db.GetAuthors();
    }

    private void OnDeleteAuthorClick(object sender, RoutedEventArgs e)
    {
        if (AuthorsLb.SelectedItem is not Author selectedAuthor)
        {
            MessageBox.Show(
                "Пожалуйста, выберите автора для удаления.",
                "Ошибка",
                MessageBoxButton.OK, 
                MessageBoxImage.Warning
            );
            return;
        }

        var show = MessageBox.Show(
            $"Вы действительно хотите удалить автора {selectedAuthor.FullName}?",
            "Подтверждение удаления",
            MessageBoxButton.YesNo
        );
        if (show != MessageBoxResult.Yes) return;
        _db.DeleteAuthor(selectedAuthor.Id);
        UpdateItems();
        MessageBox.Show("Автор успешно удален.");
    }

    private void OnAddAuthorClick(object sender, RoutedEventArgs e)
    {
        CreateAuthor window = new();
        if (window.ShowDialog() == null || window.NewAuthor == null) return;
        _db.InsertAuthor(window.NewAuthor);
        UpdateItems();
    }
}